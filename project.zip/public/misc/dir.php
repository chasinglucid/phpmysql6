<?php
echo __DIR__;