<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Random Number</title>
</head>
<body>
<p>Generating a random number between 1 and 10:
<?php
echo rand(1, 10);
?>
</p>
</body>
</html>