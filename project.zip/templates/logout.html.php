<h2>Logged out</h2>

<p>You have been logged out</p>